const confirmation = {
  'success.user.security-questions': 'Your Security Questions have been successfully updated.',
  'success.user.information': 'Your user information has been successfully updated.',
  'success.user.password': 'Your Password was changed successfully. You will be required to use your new Password the next time you access the EDI Website.',
};

export default confirmation;

