const warnings = {
};

export default warnings;

